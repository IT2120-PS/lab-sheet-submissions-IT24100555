setwd('C:\\Users\\IT24100555\\Desktop\\Lab05')
getwd()
data <-read.table("Data.txt",header=TRUE, sep=",")
fix(data)
names(data) <- c( "X1","X2")
attach(data)
hist(X2,main="Historam for Number of Shareholders")
histogram <-hist(X2,main="Historam for Number of Shareholders",breaks = seq(130,270,length=8),right=FALSE)
?hist



#1.Import the dataset
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE, sep=",")
print(Delivery_Times)

#2.Draw a histogram
hist(Delivery_Times$Delivery_Time,
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time(minutes)",
     ylab = "Frequency",
     breaks=seq(20, 70, by=5),
     right=FALSE)

#3.Comment

# The distribution appears to be right -skewd, with the majority of delivery time
# clustered between 20 and 40 minutes

#4.Draw a cumulative frequency polygon
cum_freq <- cumsum(table(cut(Delivery_Times$Delivery_Time, breaks=seq(20, 70, by=5), right = FALSE)))
plot(seq(20, 65, by=5), cum_freq, type='o',
     main = "Cumulative Frequency Polygon(ogive) for Delivery Times",
     xlab="Delivery Time(minutes)",
     ylab="Cumulative Frequency",
     ylim=c(0, max(cum_freq)),
     pch=16)



